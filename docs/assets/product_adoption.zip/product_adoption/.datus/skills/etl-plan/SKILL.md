---
name: etl-plan
description: >
  Create and confirm an execution plan before data development, ETL, data-warehouse SQL, table processing, metric definition, or report-building work. Must be used when the user asks to add or modify ETL scripts, develop target tables, process indicators, build report wide tables, fix data-processing logic, compare or reconcile metric definitions, extract implementation rules from SQL, or design an implementation plan. Before writing SQL, changing code, or executing implementation, analyze the request, define exploration goals, deeply inspect project knowledge and database metadata, write plans/<requirement-summary>.md, and iterate with the user until explicit approval is given.
tags: [etl, planning, sql, data-development, warehouse]
version: "1.2.0"
user_invocable: true
---

# ETL Plan First

For any data-development request, create a plan, get it confirmed, and only then implement. This prevents SQL work when business definitions, table structures, lineage, batch rules, or technical standards are unclear.

## Principles

1. **Plan before execution**: until the plan is explicitly approved, do not write business SQL, modify ETL code, create/alter database objects, commit executable scripts, or make implementation changes.
2. **Analyze before exploring**: first decompose the request, identify target objects, define exploration goals and evidence gaps, then explore with a clear purpose.
3. **Explore before asking**: inspect available project context first; ask the user only for remaining blockers. Do not guess business definitions, field meanings, source tables, or batch rules.
4. **Evidence-driven**: every key conclusion in the plan must cite evidence such as database metadata, historical SQL, `docs/`, `AGENTS.md`, DDL, or explicit user answers.
5. **User gate**: after writing `plans/<requirement-summary>.md`, request user confirmation. If the user asks for changes, update the plan and ask again. Begin implementation only after explicit approval.
6. **Read-only planning**: during planning, use only read-only exploration. Database queries are limited to metadata, small samples, and scope checks; do not run DDL/DML.

## When To Use

Use this skill for:

- Adding, modifying, or refactoring ETL/SQL scripts.
- Creating target tables, wide tables, mart tables, metric tables, daily/monthly reports.
- Designing extraction, cleansing, mapping, incremental loads, snapshots, partitions, or rerun approaches.
- Changing metric definitions, business rules, code mappings, filters, or adjustment logic.
- Designing table lineage, field lineage, and implementation paths in a data-warehouse project.
- Any data-development request where the user asks to plan first, confirm the approach, or avoid direct execution.

Do not use it for simple conceptual explanations or casual questions that do not lead to implementation.

## Workflow

```text
Receive data-development request
  ↓
Analyze the problem, requirement summary, and delivery boundary
  ↓
Define exploration goals, candidate objects, initial hypotheses, and evidence gaps
  ↓
Explore project context with those goals
  ↓
Ask the user once about remaining blocking questions
  ↓
Write plans/<requirement-summary>.md
  ↓
Ask the user to confirm the plan
  ↓
User requested changes? yes -> update plan -> ask again
  ↓ no, explicit approval given
Begin implementation
```

## Step 1: Analyze The Request And Design Exploration

Extract from the user request:

- Business objective: what problem is being solved and for which business line or report.
- Target object: table, file, metric, script, or data layer.
- Input clues: source tables, historical scripts, fields, definitions, date ranges, batch rules.
- Deliverables: SQL, documentation, table DDL, validation, scheduling notes, etc.
- Execution boundary: what is only planned in this round, and what may be implemented after approval.

Then define:

| Item | Requirement |
|---|---|
| Exploration goals | What must be verified, such as target-table existence, source candidates, metric definition, historical pattern, partition strategy |
| Candidate objects | Likely schemas, tables, fields, SQL files, and docs sections based on request keywords |
| Initial hypotheses | Mark as "to verify"; never write them as facts until evidenced |
| Evidence gaps | Missing DDL, code definitions, lineage, business definitions, samples, etc. |
| Priority | Check objects that affect correctness first, then adjacent scripts and shared standards |

If the request is vague, do not immediately ask. First use visible clues to complete this analysis, then explore project knowledge, then ask only remaining blockers.

## Step 2: Purposeful Deep Exploration

Explore only toward the goals from Step 1. Cover enough evidence without broad unrelated scanning.

Minimum scope:

1. **Project knowledge**
   - `AGENTS.md`
   - `docs/business_knowledge.md`
   - `docs/technical_standards.md`
   - `docs/table_lineage.md`
   - `docs/ref_sql_inventory.md`

2. **Historical SQL / reference scripts**
   - Same-layer, same-business-line, or same-processing-pattern scripts under `ref_sql/`.
   - Scripts similar to the target table, source table, metric, or business line.
   - Known adjustment scripts, debug scripts, or historical versions of the same target.

3. **Database metadata**
   - Target and candidate source table structures, field types, partition fields, distribution keys, and control fields.
   - Relevant sample data or enumerations, read-only with `LIMIT 10-20`.
   - Shared public tables such as code maps, organizations, products, customers, accounts, or loan-dubil tables.
   - For every candidate source table, collect:
     - why this table is selected rather than alternatives;
     - actual fields to use and their business meaning;
     - key filters and their business basis;
     - join keys and why those keys are appropriate.

4. **Project standards**
   - Layer and schema mapping.
   - Batch variable names.
   - Incremental/full/CDC/snapshot processing patterns.
   - Temp tables, partitions, distribution keys, `ANALYZE`, and idempotent rerun patterns.
   - 13-month rolling retention, sentinel dates, unmapped-code behavior.

If an Explore agent is available, use a focused prompt that asks for read-only exploration only. If not, perform the same read-only exploration yourself and state in the plan why an Explore agent was not used.

### Explore Agent Prompt Template

```text
Perform read-only deep exploration for this data-development request. Do not write SQL, modify files, or execute implementation.

Requirement: <original user request>

Initial analysis by the main agent:
- Business objective: <objective>
- Target object: <table/metric/script/layer>
- Delivery boundary: <planning-only / implementation after confirmation>
- Initial hypotheses to verify: <list>
- Evidence gaps: <key missing evidence>

Exploration goals:
1. <goal 1>
2. <goal 2>
3. <goal 3>
4. <goal 4>

Explore:
1. Database metadata for target and candidate source tables: structures, field types, partitions, control fields, sample values with LIMIT 10-20.
2. Historical SQL under ref_sql/ that matches the target, layer, business line, or processing pattern.
3. Project knowledge in AGENTS.md and docs/.
4. Uncertainties that affect the development plan; place them in blocking_questions and do not guess.

Return:
- requirement_understanding
- exploration_targets
- initial_hypotheses_checked
- evidence_gaps_resolved
- evidence_gaps_remaining
- related_docs
- related_sql_files
- related_tables
- target_table_metadata
- source_table_candidates:
  - table_name & schema
  - layer
  - why_selected
  - used_columns: name, type, business meaning, evidence source
  - key_filters and business basis
  - join_conditions and reasons
- lineage_findings
- business_rules
- technical_patterns
- risks
- validation_suggestions
- blocking_questions
- evidence
```

## Step 3: Ask About Blocking Questions

After exploration, ask the user once if blockers remain. Do not put unresolved blockers into the plan as facts.

Common blockers:

- Whether to create, reuse, or transform a target table.
- Metric definition, filters, status codes, or business-line scope cannot be confirmed.
- Multiple source candidates exist and evidence is insufficient.
- Batch cycle, data date, partition grain, or retention is unclear.
- Field mapping, business key, deduplication, incremental condition, or rerun logic conflicts.
- Historical SQL and docs disagree.
- Whether certain files may be added or changed.

Question rules:

- Ask all current blockers together.
- Explain why each answer affects the plan.
- If offering options, do not add an "Other" option; the user can always type freely.
- After the user answers, write or update the plan without repeatedly asking the same batch of questions.

## Step 4: Write The Plan File

Write the plan to:

```text
plans/<requirement-summary>.md
```

Naming:

- Use a short, stable, readable Chinese or English phrase.
- Avoid spaces, special characters, and overly long names.
- Examples: `plans/add_ifc_loan_daily.md`, `plans/refactor_credit_card_account_wide_table.md`.

Create `plans/` if needed. The plan must be Markdown.

### Required Plan Structure

```markdown
# <Requirement Summary> Execution Plan

## 1. Background, Requirement, And Problem Analysis
- Original user request:
- Requirement understanding:
- Problem decomposition:
- Exploration goals:
- Initial hypotheses (verified/unverified):
- Evidence gaps:
- Delivery boundary for this round:
- Items explicitly not executed:

## 2. Exploration Evidence
| Type | Source | Key Finding | Impact |
|---|---|---|---|
| Document |  |  |  |
| Historical SQL |  |  |  |
| Metadata |  |  |  |
| User confirmation |  |  |  |

## 3. Target Table Structure
- Target table:
- Layer/schema:
- Fields and types:
- Primary/unique/business keys:
- Partition field and strategy:
- Distribution key / index / storage:
- ETL control fields:
- Create new or modify existing:

## 4. Source Tables And Field Lineage

### 4.1 Source Details

#### `<schema>.<table_name>`

- **Layer**: `<ITL / IOL / ICL / IML / IDL / RDM>` - `<schema>`
- **Why selected**: why this table is used instead of alternatives.
- **Used columns**:

  | Column | Type | Business Meaning | Evidence |
  |---|---|---|---|
  | `<col>` | `<type>` | <meaning> | <DDL / docs / sample / historical SQL> |

- **Key filters**:

  | Filter | Business Basis |
  |---|---|
  | `<WHERE condition>` | <basis> |

- **Joins**:

  | Joined Table | JOIN Condition | Reason |
  |---|---|---|
  | `<other_table>` | `<join key>` | <reason> |

### 4.2 Field Lineage Mapping

| Target Field | Source Table | Source Field | Transformation | Evidence |
|---|---|---|---|---|

## 5. Processing Logic
- Overall lineage:
- Temp-table design:
- Join logic:
- Filters:
- Deduplication:
- Incremental/full/snapshot/CDC strategy:
- Rerun and idempotency:
- Partition maintenance:
- Statistics maintenance:

## 6. Metric Definitions
| Metric / Field | Definition | Filters | Time Semantics | Codes / Enums | Evidence |
|---|---|---|---|---|---|

## 7. Execution Steps
1.
2.
3.

## 8. Subagent Usage Plan
| Subagent | Phase | Task | Input | Expected Output |
|---|---|---|---|---|
| Explore | Planning | Deep exploration of metadata, historical SQL, and docs | Requirement and candidates | Evidence, risks, uncertainty |

## 9. Questions To Confirm
| Question | Current Judgment | Why It Affects Execution | Suggested Options | Status |
|---|---|---|---|---|

## 10. Risks And Validation Plan
| Risk | Impact | Mitigation | Validation SQL / Method | Responsible Phase |
|---|---|---|---|---|

## 11. Execution Permission
- Current status: waiting for user confirmation / approved for execution
- User confirmation record:
- Items that must not be executed without confirmation:
```

## Step 5: Request User Confirmation

After writing the plan, ask the user to confirm:

```text
I have written the plan file: plans/<requirement-summary>.md. Please confirm whether to proceed with implementation based on this plan.
```

Recommended choices:

- `Approve, start implementation`
- `Revise the plan; I will provide changes`
- `Do not execute for now`

## Step 6: Iterate Based On Feedback

If the user requests changes:

1. Read the feedback.
2. Add read-only exploration if needed.
3. Modify the same plan file.
4. Update affected sections.
5. Ask for confirmation again.
6. Repeat until explicit approval or cancellation.

If the user says not to execute:

- Stop; do not enter implementation.
- Keep the plan file.
- Briefly state that work can continue from the plan later.

If the user explicitly approves:

- Update the plan's "Execution Permission" status to "approved for execution".
- Then implementation may begin.
- Follow the plan. If reality conflicts with the plan, pause and return to plan revision and confirmation.

## Execution-Phase Boundary

After approval, still obey:

- Do not exceed the confirmed plan.
- Do not expand source-table scope, change definitions, or add deliverables on your own.
- Pause and ask if blockers appear during implementation.
- SQL and code must follow project technical standards.
- After completion, report actual outputs, changed files, validation method, and unfinished items.

## Examples

### Example 1: New ETL Script

User:

```text
Help me add an internet-finance loan daily ETL script.
```

Correct handling:

1. Analyze the business objective, target layer, source candidates, boundary, and evidence gaps.
2. Define exploration goals around internet-finance account/loan/asset-transfer tables, historical daily scripts, docs, and target layer.
3. Perform focused deep exploration.
4. Ask about uncertain target-table naming, daily definition, and source scope.
5. Write `plans/add_ifc_loan_daily.md`.
6. Ask for confirmation.
7. Write SQL only after approval.

### Example 2: Metric Definition Change

User:

```text
Change the five-level classification definition in the loan-dubil mart.
```

Correct handling:

1. Analyze affected target fields, business lines, historical adjustments, downstream consumers, and evidence gaps.
2. Explore `docs/business_knowledge.md`, `docs/table_lineage.md`, relevant RDM SQL, and target structure.
3. Confirm the specific rule change, effective date, business-line scope, and whether history must be restated.
4. Write a plan with affected fields, source tables, adjustment strategy, risks, and validation.
5. Modify SQL only after user confirmation.

## Output Requirements

During planning, user-facing replies should include only:

- What exploration has been completed.
- The plan file path.
- Remaining confirmation questions or confirmation entry point.
- No large implementation SQL snippets.

Before final implementation, ensure the user has explicitly selected "Approve, start implementation" or provided equivalent approval.
