---
name: execute-job
description: Execute project SQL or ETL job files, including DDL-oriented table/job operations through project tools such as gen_table and gen_job when available. Use when the user asks to execute SQL, run SQL, run a job, create or refresh target tables, replay a batch, rerun a batch, run sql, execute job, execute DDL, or provides a batch_date together with a SQL file name. This skill is runner-agnostic and must not depend on a bundled script.
tags: [job, sql, execution, batch, etl]
version: "1.3.0"
user_invocable: true
---

# Execute Job

Run a project SQL / ETL job for a specific batch date, including DDL-oriented table creation or refresh operations when the project exposes tools such as `gen_table` and `gen_job`. This skill is intentionally generic: it does not require or assume any bundled script, wrapper, or fixed database connection. Use the project's documented runner when one exists; otherwise execute the SQL with the database client available in the environment.

`ref_sql/` is historical reference material and must not be executed directly. Executable SQL should normally live under `jobs/` unless the project explicitly documents another executable-job location.

## When To Use

- The user asks to run, execute, rerun, or replay a SQL / ETL job.
- The user asks to create, refresh, or rebuild target tables through project DDL/job tooling.
- The project provides `gen_table` or `gen_job`, and the requested execution can be performed through those tools.
- The user provides a `batch_date`, such as `20260430`, and a SQL filename.
- The user wants to test one ETL step for a specific batch date.

Do not use this skill when the user is asking for SQL review, ETL design, or reconciliation rather than execution.

## Required Inputs

Confirm these before execution:

1. **SQL/job file**: usually under `jobs/`. Bare filenames should be resolved under the project's executable-job directory when possible.
2. **`batch_date`**: 8-digit `YYYYMMDD`, unless the project uses another documented batch-date format.
3. **Execution method**: project runner, `gen_table`, `gen_job`, database client, or scheduler command. If none is documented, use the local SQL client, usually `psql` for Greenplum/PostgreSQL-compatible projects.
4. **Connection context**: database host, port, database, user, and authentication method. Prefer environment variables or project config over hard-coded values.

If the SQL file is ambiguous, list candidate files first. If connection details or the batch date are missing and cannot be inferred from project config, ask the user once.

## Batch-Date Variables

When a project uses batch placeholders, derive the standard variables from `batch_date` consistently:

| Variable | Meaning | Example (`batch_date=20260430`) |
|---|---|---|
| `batch_date` | Original batch date | 20260430 |
| `last_date` | Previous day | 20260429 |
| `month_start` | First day of the current month | 20260401 |
| `next_month_start` | First day of the next month | 20260501 |
| `last_month_end` | Last day of the previous month | 20260331 |
| `year_start` | First day of the current year | 20260101 |
| `last_year_end` | Last day of the previous year | 20251231 |
| `batch_yyyymm` | `YYYYMM` derived from `batch_date` | 202604 |

If the project defines additional variables, derive them from project documentation or ask the user when they are execution-blocking.

## Execution Strategy

Use this order of preference:

1. **Project-native runner**: if docs, `AGENTS.md`, Makefile, scheduler config, or existing scripts define a runner, use it.
2. **Project DDL/job tools**: when table DDL or job generation/execution is required and tools such as `gen_table` or `gen_job` are available, use those tools according to project conventions.
3. **Database client execution**: if no runner is documented, run the SQL with the appropriate local client, such as `psql` for Greenplum/PostgreSQL.
4. **Dry-run / preview**: when the command would write production data and the user has not clearly approved execution, show or run a dry-run/preview if the execution method supports it.

Do not invent a custom runner unless the user asks for one.

## DDL Operations With Project Tools

When the request involves table creation, table refresh, DDL execution, or converting a table definition into an executable job:

- Prefer `gen_table` for table/DDL-oriented operations when the project exposes it.
- Prefer `gen_job` for job generation or job execution workflows when the project exposes it.
- Keep generated DDL/job artifacts aligned with the approved ETL plan and project naming conventions.
- Report which tool was used, what table/job it targeted, and whether the operation changed schema or data.
- Do not use `gen_table` or `gen_job` on `ref_sql/` reference SQL unless the user explicitly asks to convert reference SQL into executable jobs.

## Placeholder Handling

Inspect the SQL before execution:

- For `:var` placeholders, prefer database-client variable binding, for example `psql -v batch_date=20260430`.
- For `${var}` placeholders, render a temporary copy outside the source file, then execute the rendered copy. Never modify the source SQL just to substitute runtime variables.
- For mixed placeholder styles, make sure all placeholders are resolved or intentionally passed through to the runner.
- If unresolved placeholders remain after preparation, stop and ask rather than running a partial command.

Temporary rendered SQL should be written under an allowed temp directory or project scratch location and should not replace the original job file.

## Generic `psql` Pattern

For Greenplum/PostgreSQL-compatible projects without a documented runner:

```text
psql -h <host> -p <port> -d <database> -U <user> \
  -v ON_ERROR_STOP=1 \
  -v batch_date=<YYYYMMDD> \
  -v last_date=<YYYYMMDD> \
  -v month_start=<YYYYMMDD> \
  -v next_month_start=<YYYYMMDD> \
  -v last_month_end=<YYYYMMDD> \
  -v year_start=<YYYYMMDD> \
  -v last_year_end=<YYYYMMDD> \
  -v batch_yyyymm=<YYYYMM> \
  -f <sql-file-or-rendered-temp-file>
```

Use `PGHOST`, `PGPORT`, `PGDATABASE`, `PGUSER`, `PGPASSWORD`, `.pgpass`, or project config when available. Do not print passwords in the final response.

## Safety Checks

Before execution:

- Confirm the file is intended to be executable, usually under `jobs/`.
- Refuse to execute `ref_sql/` unless the user explicitly overrides the project convention and understands it is historical reference SQL.
- Check whether the SQL is rerunnable and idempotent for the target batch, such as `DELETE` or partition overwrite before `INSERT`.
- Confirm the command targets the intended database and schema.
- For long-running or production-sensitive jobs, prefer explicit user confirmation before execution.

## Output Handling

When reporting back, summarize:

- SQL/job file executed.
- Batch date and key derived variables.
- Execution method used.
- Target database context, excluding secrets.
- Exit code and elapsed time when available.
- Important `ERROR:`, warning, or unresolved-placeholder messages.
- Whether the job completed, failed, or needs user action.

If the command times out or output is too large, state what was observed and recommend rerunning the same command in a long-lived shell/session.

## Constraints

- This skill executes jobs; it does not modify SQL files.
- It must not depend on a specific bundled script or wrapper.
- It may use project-provided tools such as `gen_table` and `gen_job` for DDL/table/job execution when available.
- It must not execute historical reference SQL under `ref_sql/` by default.
- It must not hide failed commands, unresolved variables, or partial execution.
