---
name: sql-review
description: >
  Review generated ETL job SQL against its confirmed plan. Use whenever the user asks to review, audit, inspect, verify, accept, or compare jobs/*.sql with plans/*.md, especially for SQL logic correctness, plan compliance, hard-coded values, batch variables, Greenplum/PostgreSQL ETL conventions, idempotency, partitions, lineage, and maintainability. Produce a review report first, ask for confirmation on uncertain items and proposed fixes, and modify only jobs SQL after the user explicitly agrees.
tags: [sql, review, etl, jobs, plan, greenplum]
version: "1.0.0"
user_invocable: true
---

# SQL Review

Review whether generated `jobs/` SQL matches the corresponding `plans/` document and this project's ETL standards. First produce a review and a fix proposal, then confirm with the user. Modify `jobs/` SQL only after the user explicitly agrees. Do not execute SQL and do not modify plan files on your own.

## Goals

1. **Plan compliance**: Check that target tables, grain, sources, lineage, business rules, filters, formulas, date ranges, partitions, and retention rules match `plans/*.md`.
2. **Logic correctness**: Inspect joins, aggregation, deduplication, amount signs, date semantics, stock/new-event logic, null/blank handling, code mappings, business-line splits, and final rollups.
3. **Hard-coding and parameterization**: Identify unsafe fixed dates, schemas, organizations, products, statuses, temp paths, and debug filters. Distinguish valid business constants from risky hard-coded values.
4. **Engineering quality**: Check that `jobs/` scripts are self-contained, rerunnable, idempotent, maintainable, and aligned with Greenplum/PostgreSQL and project layering conventions.
5. **Fix loop**: Provide executable remediation; collect uncertain questions; update SQL only after approval.

## When To Use

Use this skill for requests such as:

- "Review this job SQL against the plan."
- "Check whether `jobs/xxx.sql` matches `plans/xxx.md`."
- "Look for hard-coding or logic issues in the generated SQL."
- "Give me a fix proposal first; I will confirm before you edit."
- "Audit / accept / verify this ETL SQL."

Do not use it for:

- Developing new ETL SQL from scratch; use the planning/development workflow first.
- Executing SQL or replaying a batch.
- Pure database analysis, metric querying, or report interpretation.
- Modifying historical scripts under `ref_sql/`.

## Input Recognition

Extract from the user request:

- `job_sql`: the SQL to review, usually `jobs/*.sql`.
- `plan_doc`: the matching plan, usually `plans/*.md`.
- Review focus: logic, hard-coding, plan compliance, rerun safety, etc.
- Edit authorization: only explicit language such as "apply the fix" or "modify it as proposed" counts as permission.

If files are not specified:

1. List candidate `jobs/*.sql` and `plans/*.md` files.
2. Infer the most likely pair by target table, requirement summary, and filename similarity.
3. If not unique, ask the user once to confirm the SQL and plan files.

## Workflow

```text
Identify job_sql and plan_doc
  ↓
Collect read-only evidence: plan, SQL, docs, metadata, relevant references
  ↓
Build a checklist from the plan and a checklist from the SQL implementation
  ↓
Compare item by item, with evidence, severity, and fix recommendations
  ↓
If uncertain items or edits are needed, ask the user for confirmation
  ↓
User approved edits?
  ├─ yes: modify only jobs/ SQL, then report the diff summary and remaining risks
  └─ no / not approved: do not edit files; output the review report only
```

## Step 1: Collect Evidence Read-Only

Read and understand the plan and SQL first:

- `plan_doc`: target table, layer, business grain, field list, sources, formulas, filters, batch rules, partitions, retention, confirmed user decisions, risks, and deferred items.
- `job_sql`: target table, parameters, temp-table steps, sources, joins, filters, grouping, final insert, analyze statements, comments, TODOs, and known degradations.
- `docs/technical_standards.md`, `docs/business_knowledge.md`, and `docs/table_lineage.md`: only read relevant sections.
- Relevant same-layer or same-business reference SQL under `ref_sql/` when useful for pattern comparison.
- Database metadata only when necessary, for read-only structure/sample checks such as `describe_table`. Sample queries must use `LIMIT 10-20`; do not run full analytical checks.

Database tools are for metadata and small samples only. Do not execute review SQL, compute production metrics, or write data.

## Step 2: Build The Review Checklist

Break the plan into checkable items:

| Category | Items To Check |
|---|---|
| Delivery boundary | Only confirmed scope is implemented; deferred/TODO items are not accidentally delivered |
| Target table | Schema, table, fields, assumed types, control fields, distribution key, partition strategy |
| Grain | `etl_dt`, statistic month, organization, product, account, loan-dubil, or other dimensions |
| Source tables | Each metric uses the planned source; unconfirmed substitute sources are flagged |
| Business rules | Five-level classification, non-performing rules, overdue, write-off, recovery, batch transfer, provision, insurance claim, etc. |
| Date semantics | Current month/year, previous month end, previous year end, month-end batch, inclusive/exclusive ranges |
| Rollup logic | Business-line split before aggregation, duplicate control, and whether `DISTINCT` hides data issues |
| Join logic | Complete keys, LEFT vs INNER choice, fuzzy matching risk, multi-version dimension filters |
| Idempotency | Delete/reload by batch or partition; no accidental deletion outside current batch |
| Greenplum conventions | Temp tables, distribution keys, `ANALYZE`, partition creation, DDL inside/outside transactions |
| Batch variables | Correct use of `${batch_date}` and derived variables; no fixed dates or environment hard-coding |
| Maintainability | Comments, naming, step structure, validation temp tables, explicit TODOs |

## Step 3: Hard-Coding Rules

Do not mark every constant as a defect.

### High-Risk Hard-Coding

Usually must be fixed:

- Fixed batch dates such as `20260430`, `date '2026-04-30'`, or `'202604'` instead of `${batch_date}` or derived variables.
- Fixed schemas when the project has variable conventions or cross-environment requirements.
- Debug filters for one organization, product, account, customer, loan, or a production `LIMIT`.
- Temporary test tables, personal schemas, local paths, or external files.
- Values such as `UNKNOWN`, `0`, or blank strings that silently hide data loss or logic failure.

### Business Constants That Need Evidence Or Confirmation

- Five-level classification groups such as `'03','04','05'`.
- Disposal types, transaction codes, event codes, and business-line codes.
- Product/organization special lists and credit-card exclusion lists.
- Code mappings not clearly supported by the plan, docs, or reference SQL.

If supported by the plan, docs, or historical SQL, mark them as evidence-backed business constants. Otherwise mark them as items to confirm.

### Acceptable Engineering Constants

- Temp table names and step numbers.
- Fixed `etl_task_no` when required by the project standard.
- `ANALYZE`, `DISTRIBUTED BY`, and similar engineering statements.
- Planned default values that do not mask data loss.

## Step 4: Focus Areas

### Plan Mismatch

Mark as `BLOCKER` or `HIGH` when:

- The SQL target table, grain, or sources differ from the plan.
- Required atomic metrics are missing, or the SQL adds important unconfirmed metrics.
- The plan says rate/formula fields are frontend-derived, but SQL persists them.
- The plan requires business-line-specific logic, but SQL mixes lines before aggregation.
- Explicitly confirmed plan decisions are not implemented.

### SQL Logic Risks

Check for:

- `LEFT JOIN` degraded to `INNER JOIN` by right-table filters in `WHERE`.
- Many-to-many joins without pre-aggregation, causing amount amplification.
- `LIKE '%' || key`, non-equi joins, or truncated-key joins causing false matches.
- Mixed date formats, unsafe `to_date`, or off-by-one date ranges.
- `GROUP BY` less granular than the target grain, or unstable grouping fields causing duplicates.
- `SELECT DISTINCT` used to hide duplicates instead of explaining them.
- Incorrect amount signs, debit/credit direction, reversals, or cancellations.
- Null/blank handling that breaks joins or misclassifies records.
- Snapshot tables missing `etl_dt` or zipper effective-date filters.
- Partition DDL in unsafe transaction contexts, or final writes without idempotent deletes.

### Project Conventions

Check that:

- `jobs/` scripts use `${batch_date}` and project batch variables.
- Complex RDM processing usually follows temp-table steps, `ANALYZE`, final `DELETE WHERE etl_dt = batch_date`, final `INSERT`, and target `ANALYZE`.
- IML/IOL/ICL/RDM schemas match the documented layer mapping.
- `ref_sql/` remains read-only and is not used as the execution target.
- `VACUUM` is not enabled unless the user or standard explicitly requires it.
- 13-month retention, month/day partitions, and month-end retention match the plan.

## Report Format

Use Markdown by default:

```markdown
# SQL Review: <job_sql>

## 1. Summary
- Verdict: pass / conditional pass / fail
- Plan file: <plan_doc>
- SQL file: <job_sql>
- Main risks: ...
- Recommended edits: yes/no

## 2. Blockers
| ID | Issue | Evidence | Impact | Fix |
|---|---|---|---|---|

## 3. Findings
| Severity | Category | Issue | Evidence location | Impact | Recommendation |
|---|---|---|---|---|---|

## 4. Plan Compliance
| Plan requirement | SQL implementation | Verdict | Evidence |
|---|---|---|---|

## 5. Hard-Coding And Parameterization
| Constant / pattern | Assessment | Evidence | Recommendation |
|---|---|---|---|

## 6. Fix Proposal
- Option A (recommended): ...
- Option B (optional): ...
- Files to edit: only `jobs/...sql`
- Files not to edit: `plans/...md`; suggest plan changes only if needed

## 7. Questions To Confirm
- [ ] <question and why it matters>

## 8. Edit Result
- If not authorized: no files were modified.
- If authorized: list actual edits, remaining risks, and suggested validation.
```

Severity levels:

- `BLOCKER`: severe plan mismatch, incorrect result, non-rerunnable SQL, or production unusability.
- `HIGH`: likely metric deviation, amount amplification/loss, or cross-environment failure.
- `MEDIUM`: unclear business rule, performance risk, or maintainability issue.
- `LOW`: non-blocking comments, naming, formatting, or readability issue.
- `INFO`: evidence-backed explanatory finding.

## Confirmation And Edit Rules

Ask the user before proceeding when:

- `job_sql` or `plan_doc` cannot be identified uniquely.
- Business rules, code values, source substitutions, amount signs, or date ranges cannot be proven from the plan/docs/reference SQL.
- A fix would change metric semantics, sources, target fields, deletion scope, or output grain.
- Any `jobs/` SQL file needs modification.
- The user asked to confirm before editing.

Collect all current questions in one batch.

Edit boundaries:

- Only edit `jobs/*.sql` after explicit user approval.
- Do not automatically modify `plans/*.md`; suggest plan revisions in the report instead.
- Do not modify `ref_sql/`, `docs/`, `AGENTS.md`, or database objects.
- Do not run DDL/DML or production SQL.
- Preserve the original SQL intent and make the smallest necessary change.

After approved edits:

1. Apply precise edits.
2. Re-read the changed snippets to confirm the issue was addressed.
3. Report fixed finding IDs, changed files, core edits, remaining risks, and recommended validation.

## Final Response

Always respond in English after using this English skill. Keep the conclusion clear, evidence-based, and actionable. Do not guess unknown business rules; mark them as requiring confirmation and explain the impact. If the user has not authorized edits, explicitly state that no files were modified.
