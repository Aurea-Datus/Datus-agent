#!/usr/bin/env python3
"""One-time migration from DuckDB schemas to PostgreSQL.

The migration scope is controlled by the comma-separated SCHEMAS environment
variable. The project compose file migrates raw and marts by default.

    docker compose run --rm duckdb-loader

After a successful migration, PostgreSQL owns the persisted data and the DuckDB
file is no longer needed for normal operation.
"""

from __future__ import annotations

import csv
import io
import os
import sys
import time
from dataclasses import dataclass
from decimal import Decimal
from typing import Iterable

import duckdb
import psycopg
from psycopg import sql


SYSTEM_SCHEMAS = {"information_schema", "pg_catalog", "main"}


@dataclass(frozen=True)
class Column:
    name: str
    duckdb_type: str
    ordinal: int


def env(name: str, default: str) -> str:
    return os.environ.get(name, default)


def requested_schemas() -> list[str]:
    raw = env("SCHEMAS", "raw")
    schemas = [part.strip() for part in raw.split(",") if part.strip()]
    return [schema for schema in schemas if schema not in SYSTEM_SCHEMAS]


def quote_pg_ident(name: str) -> sql.Identifier:
    return sql.Identifier(name)


def pg_type(duckdb_type: str) -> str:
    t = duckdb_type.upper().strip()
    if t.startswith("VARCHAR") or t == "UUID":
        return "TEXT"
    if t in {"BIGINT", "INT8"}:
        return "BIGINT"
    if t in {"INTEGER", "INT", "INT4"}:
        return "INTEGER"
    if t in {"SMALLINT", "INT2"}:
        return "SMALLINT"
    if t in {"TINYINT"}:
        return "SMALLINT"
    if t in {"UBIGINT", "HUGEINT", "UHUGEINT"}:
        return "NUMERIC(38,0)"
    if t.startswith("DECIMAL") or t.startswith("NUMERIC"):
        return "NUMERIC"
    if t in {"DOUBLE", "FLOAT8"}:
        return "DOUBLE PRECISION"
    if t in {"FLOAT", "REAL", "FLOAT4"}:
        return "REAL"
    if t == "BOOLEAN":
        return "BOOLEAN"
    if t == "DATE":
        return "DATE"
    if t.startswith("TIMESTAMP"):
        return "TIMESTAMP"
    if t == "TIME":
        return "TIME"
    return "TEXT"


def wait_for_postgres(conninfo: str, timeout_seconds: int = 90) -> None:
    deadline = time.time() + timeout_seconds
    last_error: Exception | None = None
    while time.time() < deadline:
        try:
            with psycopg.connect(conninfo, connect_timeout=5) as conn:
                conn.execute("SELECT 1")
                return
        except Exception as exc:  # pragma: no cover - depends on container timing
            last_error = exc
            time.sleep(2)
    raise RuntimeError(f"PostgreSQL did not become ready within {timeout_seconds}s: {last_error}")


def duckdb_tables(con: duckdb.DuckDBPyConnection, schemas: list[str]) -> list[tuple[str, str]]:
    placeholders = ", ".join("?" for _ in schemas)
    return con.execute(
        f"""
        SELECT table_schema, table_name
        FROM information_schema.tables
        WHERE table_type = 'BASE TABLE'
          AND table_schema IN ({placeholders})
        ORDER BY table_schema, table_name
        """,
        schemas,
    ).fetchall()


def duckdb_columns(con: duckdb.DuckDBPyConnection, schema: str, table: str) -> list[Column]:
    rows = con.execute(
        """
        SELECT column_name, data_type, ordinal_position
        FROM information_schema.columns
        WHERE table_schema = ?
          AND table_name = ?
        ORDER BY ordinal_position
        """,
        [schema, table],
    ).fetchall()
    return [Column(name=row[0], duckdb_type=row[1], ordinal=row[2]) for row in rows]


def create_pg_table(pg: psycopg.Connection, schema: str, table: str, columns: list[Column]) -> None:
    column_defs = [
        sql.SQL("{} {}").format(quote_pg_ident(col.name), sql.SQL(pg_type(col.duckdb_type)))
        for col in columns
    ]
    with pg.cursor() as cur:
        cur.execute(sql.SQL("CREATE SCHEMA IF NOT EXISTS {}").format(quote_pg_ident(schema)))
        cur.execute(
            sql.SQL("DROP TABLE IF EXISTS {}.{} CASCADE").format(
                quote_pg_ident(schema), quote_pg_ident(table)
            )
        )
        cur.execute(
            sql.SQL("CREATE TABLE {}.{} ({})").format(
                quote_pg_ident(schema), quote_pg_ident(table), sql.SQL(", ").join(column_defs)
            )
        )


def normalize_value(value):
    if isinstance(value, Decimal):
        return str(value)
    return value


def copy_rows(
    duck: duckdb.DuckDBPyConnection,
    pg: psycopg.Connection,
    schema: str,
    table: str,
    columns: list[Column],
    batch_size: int,
) -> int:
    col_names = [col.name for col in columns]
    select_cols = ", ".join(f'"{name}"' for name in col_names)
    cursor = duck.execute(f'SELECT {select_cols} FROM "{schema}"."{table}"')

    copy_sql = sql.SQL("COPY {}.{} ({}) FROM STDIN WITH (FORMAT CSV)").format(
        quote_pg_ident(schema),
        quote_pg_ident(table),
        sql.SQL(", ").join(quote_pg_ident(name) for name in col_names),
    )

    total = 0
    with pg.cursor() as cur:
        with cur.copy(copy_sql) as copy:
            while True:
                rows = cursor.fetchmany(batch_size)
                if not rows:
                    break
                buffer = io.StringIO()
                writer = csv.writer(buffer, lineterminator="\n")
                for row in rows:
                    writer.writerow([normalize_value(value) for value in row])
                copy.write(buffer.getvalue())
                total += len(rows)
    return total


def main() -> int:
    duckdb_path = env("DUCKDB_PATH", "/data/pendo_start.duckdb")
    schemas = requested_schemas()
    batch_size = int(env("BATCH_SIZE", "5000"))

    if not schemas:
        print("No schemas requested. Set SCHEMAS=raw or another comma-separated schema list.", file=sys.stderr)
        return 1
    if not os.path.exists(duckdb_path):
        print(f"DuckDB file not found: {duckdb_path}", file=sys.stderr)
        return 1

    conninfo = " ".join(
        [
            f"host={env('PGHOST', 'postgres')}",
            f"port={env('PGPORT', '5432')}",
            f"dbname={env('PGDATABASE', 'pendo')}",
            f"user={env('PGUSER', 'pendo')}",
            f"password={env('PGPASSWORD', 'pendo')}",
        ]
    )

    print(f"Waiting for PostgreSQL at {env('PGHOST', 'postgres')}:{env('PGPORT', '5432')}...")
    wait_for_postgres(conninfo)

    duck = duckdb.connect(duckdb_path, read_only=True)
    tables = duckdb_tables(duck, schemas)
    if not tables:
        print(f"No DuckDB tables found for schemas: {', '.join(schemas)}", file=sys.stderr)
        return 1

    print(f"Migrating {len(tables)} table(s) from DuckDB schemas: {', '.join(schemas)}")
    with psycopg.connect(conninfo) as pg:
        pg.autocommit = False
        for schema, table in tables:
            columns = duckdb_columns(duck, schema, table)
            print(f"Migrating {schema}.{table} ({len(columns)} columns)...")
            create_pg_table(pg, schema, table, columns)
            copied = copy_rows(duck, pg, schema, table, columns, batch_size)
            pg.commit()
            print(f"  copied {copied:,} row(s)")

    duck.close()
    print("DuckDB to PostgreSQL migration complete. PostgreSQL is now the persistent data store.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
