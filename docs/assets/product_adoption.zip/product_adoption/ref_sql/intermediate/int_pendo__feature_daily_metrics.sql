CREATE SCHEMA IF NOT EXISTS intermediate;

CREATE OR REPLACE TABLE intermediate.int_pendo__feature_daily_metrics AS
WITH first_activity AS (
    SELECT
        visitor_id,
        account_id,
        feature_id,
        MIN(CAST(occurred_at AS DATE)) AS first_occurred_on
    FROM staging.stg_pendo__feature_event
    GROUP BY
        visitor_id,
        account_id,
        feature_id
),
daily_feature_usage AS (
    SELECT
        CAST(occurred_at AS DATE) AS occurred_on,
        feature_id,
        SUM(num_events) AS sum_clicks,
        COUNT(*) AS count_click_events,
        COUNT(DISTINCT visitor_id) AS count_visitors,
        COUNT(DISTINCT account_id) AS count_accounts,
        SUM(num_minutes) AS sum_minutes
    FROM staging.stg_pendo__feature_event
    GROUP BY
        CAST(occurred_at AS DATE),
        feature_id
),
daily_first_time AS (
    SELECT
        first_occurred_on AS occurred_on,
        feature_id,
        COUNT(DISTINCT visitor_id) AS count_first_time_visitors,
        COUNT(DISTINCT account_id) AS count_first_time_accounts
    FROM first_activity
    GROUP BY
        first_occurred_on,
        feature_id
),
daily_totals AS (
    SELECT
        occurred_on,
        SUM(sum_clicks) AS total_feature_clicks,
        SUM(count_visitors) AS total_feature_visitors,
        SUM(count_accounts) AS total_feature_accounts
    FROM daily_feature_usage
    GROUP BY occurred_on
)
SELECT
    u.occurred_on,
    u.feature_id,
    u.sum_clicks,
    u.count_click_events,
    u.count_visitors,
    u.count_accounts,
    COALESCE(f.count_first_time_visitors, 0) AS count_first_time_visitors,
    COALESCE(f.count_first_time_accounts, 0) AS count_first_time_accounts,
    u.count_visitors - COALESCE(f.count_first_time_visitors, 0) AS count_return_visitors,
    u.count_accounts - COALESCE(f.count_first_time_accounts, 0) AS count_return_accounts,
    u.sum_minutes,
    CASE WHEN u.count_visitors = 0 THEN NULL ELSE ROUND(u.sum_minutes / u.count_visitors, 3) END AS avg_daily_minutes_per_visitor,
    CASE WHEN u.count_visitors = 0 THEN NULL ELSE ROUND(u.sum_clicks / u.count_visitors, 3) END AS avg_daily_clicks_per_visitor,
    CASE WHEN t.total_feature_clicks = 0 THEN NULL ELSE ROUND(100 * u.sum_clicks / t.total_feature_clicks, 3) END AS percent_of_daily_feature_clicks,
    CASE WHEN t.total_feature_visitors = 0 THEN NULL ELSE ROUND(100 * u.count_visitors / t.total_feature_visitors, 3) END AS percent_of_daily_feature_visitors,
    CASE WHEN t.total_feature_accounts = 0 THEN NULL ELSE ROUND(100 * u.count_accounts / t.total_feature_accounts, 3) END AS percent_of_daily_feature_accounts
FROM daily_feature_usage AS u
LEFT JOIN daily_first_time AS f
    ON u.occurred_on = f.occurred_on
   AND u.feature_id = f.feature_id
LEFT JOIN daily_totals AS t
    ON u.occurred_on = t.occurred_on;
