CREATE SCHEMA IF NOT EXISTS marts;

CREATE OR REPLACE TABLE marts.pendo__feature_daily_metrics AS
SELECT
    m.occurred_on AS date_day,
    m.feature_id,
    f.feature_name,
    f.group_id AS product_area_id,
    f.page_id,
    f.page_name,
    m.sum_clicks,
    m.count_click_events,
    m.count_visitors,
    m.count_accounts,
    m.count_first_time_visitors,
    m.count_first_time_accounts,
    m.count_return_visitors,
    m.count_return_accounts,
    m.sum_minutes,
    m.avg_daily_minutes_per_visitor,
    m.avg_daily_clicks_per_visitor,
    m.percent_of_daily_feature_clicks,
    m.percent_of_daily_feature_visitors,
    m.percent_of_daily_feature_accounts
FROM intermediate.int_pendo__feature_daily_metrics AS m
LEFT JOIN intermediate.int_pendo__feature_info AS f
    ON m.feature_id = f.feature_id;
